# تشغيل النظام الحقيقي

## المكونات
- Node.js + Express API
- PostgreSQL
- لوحة إدارة محمية بتسجيل دخول
- تقديم طلب عام
- رقم طلب تلقائي
- تتبع عام برقم الطلب
- تحديث الحالة والرد من لوحة الإدارة

Express يدعم ربط PostgreSQL عبر drivers مثل pg/pg-promise.

## المتغيرات المطلوبة
انسخ `.env.example` إلى `.env` وضع:
DATABASE_URL
JWT_SECRET
ADMIN_EMAIL
ADMIN_PASSWORD
CORS_ORIGIN

## تشغيل
npm install
node seed-admin.js
npm start

## ملاحظة مهمة
هذا النظام لا يرسل رسالة واتساب تلقائيًا من حساب المؤسسة. زر واتساب يفتح محادثة مع الرقم الموجود في الطلب. الإرسال الآلي يحتاج WhatsApp Business Platform/API.
